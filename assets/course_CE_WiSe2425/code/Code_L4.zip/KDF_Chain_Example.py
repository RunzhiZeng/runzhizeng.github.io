"""This example code shows 
    (1) How to derive a key with a desired length from HKDF
    (2) Construct a key chain
"""

from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.backends import default_backend


# KDF Key Chain using HKDF
# Since a key chain 'object' can be reused, we define it as a class
# Important parameter: 
#   chain_key_length: 32 bytes by default
#   encryption_key_length: 16 (IV) + 32 (Key) bytes for AES-GCM-256

class SymmetricKeyChain_HKDF:
    def __init__(self, 
                 initial_key_material, # Initial Secret
                 hash_func = hashes.SHA256(),
                 encryption_key_length = 16 + 32, 
                 chain_key_length = 32, 
                 salt = None, 
                 info = b"This Key Chain is for Teaching. Thank you for your collaboration."
                 ):
        # Make sure the ikm is in byte format
        if not isinstance(initial_key_material, bytes):
            raise TypeError("The initial secret must be of type 'bytes'.")
        
        self.current_chain_key = initial_key_material
        self.current_encryption_key = None
        self.salt = salt
        self.info = info
        self.backend = default_backend()
        self.hash_func = hash_func
        self.ek_length = encryption_key_length
        self.ck_length = chain_key_length
        self.derive_length = self.ek_length + self.ck_length
        self.num_stage = 0                   # Iteration times

    def derive_next_keys(self):
        # Use HKDF to derive 32 + 16 + 32 = 80 bytes, split into 32-byte chain key and 48-byte encryption key
        # Note: Since the HKDF method in hazmat has already implemented Extract and Expand internally, here we just use the HKDF method directly.
        hkdf = HKDF(
            algorithm = self.hash_func,                 # The hash function for HMAC
            length = self.derive_length,                 # 64 bytes: 32 for Chain Key, 32 for Encryption Key
            salt = self.salt,            # Optional salt
            info = self.info,            # Info for context separation
            backend = self.backend
        )
        derived_key = hkdf.derive(self.current_chain_key)
        
        # Split into new chain key and encryption key
        new_chain_key = derived_key[:self.ck_length]
        new_encryption_key = derived_key[self.ck_length:self.derive_length]
        
        # Update the keys for the next iteration
        self.current_chain_key = new_chain_key
        self.current_encryption_key = new_encryption_key

    def get_chain_key(self):
        # Output the current encryption key
        chain_key = self.current_chain_key
        return chain_key

    def get_encryption_key(self):
        # Output the current encryption key
        encryption_key = self.current_encryption_key
        return encryption_key


def main():
    # Generate EC Key Pair
    CURVE = ec.SECP256R1()
    private_key = ec.generate_private_key(CURVE, default_backend())
    public_key = private_key.public_key()

    # Generate EC Key Pair of a peer
    peer_private_key = ec.generate_private_key(CURVE, default_backend())
    peer_public_key = peer_private_key.public_key()

    # Generate a ECDH shared secret as an initial secret of a KDF chain
    shared_secret = private_key.exchange(ec.ECDH(), peer_public_key) 
    ikm = shared_secret # Already in bytes, no conversion needed

    # Initialize a KDF chain
    KDF_chain = SymmetricKeyChain_HKDF(ikm)

    # Length of Key Chain
    KDF_length = 10

    # Generate and print multiple keys in the key chain
    for i in range(KDF_length):
        KDF_chain.derive_next_keys()
        print(f"Step {i + 1}:")
        print(f"  Chain Key (hex): {KDF_chain.get_chain_key().hex()}")
        print(f"  Encryption Key (hex): {KDF_chain.get_encryption_key().hex()}")

if __name__ == "__main__":
    main()