"""This example code shows 
    (1) how to use a ECDH key pair for doing DHKE and DSA
"""

from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

CURVE = ec.SECP256R1()
HASH_FUNC = hashes.SHA256()

# ECDH
def DHKE_ec(peer_public_key, my_private_key):
    shared_secret = my_private_key.exchange(ec.ECDH(), peer_public_key)
    return shared_secret

# decode a ECDH key pair of cryptography.hazmat to a readable string
def decode_pk(public_key):
    public_point = public_key.public_numbers()
    public_point_hex = (hex(public_point.x)[2:], hex(public_point.y)[2:]) # [2:] means that we remove the 0x prefix
    return public_point_hex

def decode_sk(private_key):
    private_int = private_key.private_numbers().private_value
    private_hex = hex(private_int)[2:]
    return private_hex


# ECDSA signing algorithm
def DSA_sign(private_key, message):
    signature = private_key.sign(
        message,
        ec.ECDSA(HASH_FUNC)
    )
    return signature


# Verify the ECDSA Signature
def DSA_verify(public_key, message, signature):
    try:
        public_key.verify(signature, message, ec.ECDSA(HASH_FUNC))
        return True
    except Exception as e:
        return False

def main():
    # Generate EC Key Pair
    private_key = ec.generate_private_key(CURVE, default_backend())
    public_key = private_key.public_key()

    # Generate EC Key Pair of a peer
    peer_private_key = ec.generate_private_key(CURVE, default_backend())
    peer_public_key = peer_private_key.public_key()

    print(f"The Key Pair:\n pk = {decode_pk(public_key)}, \n sk = {decode_sk(private_key)}")

    # Derive a shared secret using ECDH
    shared_secret = DHKE_ec(peer_public_key, private_key)
    print("Shared Secret (ECDH):", shared_secret.hex())

    # Sign a message
    message = b"Hello, this is a test message!"
    signature = DSA_sign(private_key, message)
    print("Signature (ECDSA):", signature.hex())
    
    # Verify the signature
    is_valid = DSA_verify(public_key, message, signature)
    assert is_valid == True

if __name__ == "__main__":
    main()