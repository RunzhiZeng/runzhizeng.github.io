import hashlib

target_hash_pw = "e8acff88511d7f8e48f038001c24d7b1ab76d9233d7894fa936c4c7c93d2c917"

def sha3_256_hex(input_data):
    sha3_256_hash = hashlib.sha3_256()
    sha3_256_hash.update(input_data.encode('utf-8'))
    return sha3_256_hash.hexdigest()

if __name__ == "__main__":
    input_data = "test_sample"
    result = sha3_256_hex(input_data)
    print(f"Target hash: {target_hash_pw}")
    print(f"Input: {input_data}")
    print(f"SHA3-256 Hash (Hex): {result}")
